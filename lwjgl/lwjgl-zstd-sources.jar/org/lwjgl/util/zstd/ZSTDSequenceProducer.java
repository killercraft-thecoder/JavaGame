/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.util.zstd;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke ZSTD_sequenceProducer_F} */
public abstract class ZSTDSequenceProducer extends Callback implements ZSTDSequenceProducerI {

    /**
     * Creates a {@code ZSTDSequenceProducer} instance from the specified function pointer.
     *
     * @return the new {@code ZSTDSequenceProducer}
     */
    public static ZSTDSequenceProducer create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable ZSTDSequenceProducer createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code ZSTDSequenceProducer} instance that delegates to the specified {@code ZSTDSequenceProducerI} instance. */
    public static ZSTDSequenceProducer create(ZSTDSequenceProducerI instance) { return create(instance, instance.address()); }

    private static ZSTDSequenceProducer create(ZSTDSequenceProducerI instance, long functionPointer) {
        return instance instanceof ZSTDSequenceProducer
            ? (ZSTDSequenceProducer)instance
            : new ZSTDSequenceProducer(functionPointer) {
                @Override public long invoke(long sequenceProducerState, long outSeqs, long outSeqsCapacity, long src, long srcSize, long dict, long dictSize, int compressionLevel, long windowSize) {
                    return instance.invoke(sequenceProducerState, outSeqs, outSeqsCapacity, src, srcSize, dict, dictSize, compressionLevel, windowSize);
                }
            };
    }

    protected ZSTDSequenceProducer() {
        super(DESCRIPTOR);
    }

    ZSTDSequenceProducer(long functionPointer) {
        super(functionPointer);
    }

}